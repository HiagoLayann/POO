package com.mycompany.atributoinstancia;

public class Principal {
    public static void main(String[] args) {
        Carro carro = new Carro();
        Computador computador = new Computador();

        carro.modelo = "Focus";
        carro.marca = "Ford";
        carro.numeroplaca = 43284028;
        carro.numerochassi = 35232;
        carro.tamanho = "5x5";
        
        /// COMPUTADOR
        computador.cpu = "i5";
        computador.monitor = "19''";
        computador.teclado = "Goldentec";
        computador.mouse = "Goldentec";
        computador.caixasom = "Goldentec";
        
        System.out.println("modelo: " + carro.modelo + " marca: " + carro.marca + " numeroPlaca: " + carro.numeroplaca + " numeroChassi: " + carro.numerochassi + " tamanho: " + carro.tamanho);
        
        System.out.println("cpu: " + computador.cpu + " monitor: " + computador.monitor + " teclado: " + computador.teclado + " mouse: " + computador.mouse + " caixasom: " + computador.caixasom);
    }
}
