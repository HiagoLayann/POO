package com.mycompany.atributoinstancia;

public class Moto {
    public String modelo;
    public String marca;
    public int numeroplaca;
    public int numerochassi;
    public int numeromotor;
}
