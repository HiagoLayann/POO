package com.mycompany.atributoinstancia;

public class Carro {
    public String modelo;
    public String marca;
    public int numeroplaca;
    public int numerochassi;
    public String tamanho;
}
