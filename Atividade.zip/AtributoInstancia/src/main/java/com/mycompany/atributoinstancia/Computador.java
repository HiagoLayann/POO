package com.mycompany.atributoinstancia;

public class Computador {
    public String cpu;
    public String monitor;
    public String teclado;
    public String mouse;
    public String caixasom;
}
