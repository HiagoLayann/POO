package com.mycompany.atributoinstancia;

public class Homem {
    public String cpf;
    public String rg;
    public String nome;
    public String cidade;
    public int idade;
}
