package com.mycompany.atributoclasse;

public class Principal {
    public static void main(String[] args) {
        
        Cachorro.nome = "Xuxu";
        Cachorro.raca = "Vira-Lata";
        Cachorro.tamanho = "20cm";
        Cachorro.pernas = 4;
        Cachorro.pelo = "Tem";

        Galinha.bico = "7cm";
        Galinha.raca = "Capoeira";
        Galinha.tamanho = "15cm";
        Galinha.poeovos = true;
        Galinha.corPenas = "Branca";
        
        System.out.println("nome: " + Cachorro.nome + " raça: " + Cachorro.raca + " tamanho: " + Cachorro.tamanho + " pernas: " + Cachorro.pernas + " pelo: " + Cachorro.pelo);
        
        System.out.println("bico: " + Galinha.bico + " raça: " + Galinha.raca + " tamanho: " + Galinha.tamanho + " poeOvos: " + Galinha.poeovos + " corPenas: " + Galinha.corPenas); 
    }
}
