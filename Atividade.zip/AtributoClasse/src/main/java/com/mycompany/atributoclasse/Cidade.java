package com.mycompany.atributoclasse;

public class Cidade {
    public static String nome;
    public static String cep;
    public static String uf;
    public static int quantidadehab;
    public static String area;
}
