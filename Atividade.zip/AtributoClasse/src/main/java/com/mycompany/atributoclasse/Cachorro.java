package com.mycompany.atributoclasse;

public class Cachorro {
    public static String nome;
    public static String raca;
    public static String tamanho;
    public static int pernas;
    public static String pelo;
}
