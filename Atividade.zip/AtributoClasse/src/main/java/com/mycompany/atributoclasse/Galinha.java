package com.mycompany.atributoclasse;

public class Galinha {
    public static String bico;
    public static String raca;
    public static String tamanho;
    public static boolean poeovos;
    public static String corPenas;
}
