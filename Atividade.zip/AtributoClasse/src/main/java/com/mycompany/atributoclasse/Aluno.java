package com.mycompany.atributoclasse;

public class Aluno {
    public static String nome;
    public static String curso;
    public static int idade;
    public static int matricula;
    public static String altura;
}
